<?php
// @deprecated Backwards compatibility with earlier 3.x versions.
class_alias('Cake\Http\Client\FormData', 'Cake\Network\Http\FormData');
