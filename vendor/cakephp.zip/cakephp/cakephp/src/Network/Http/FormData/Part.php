<?php
class_alias('Cake\Http\Client\FormDataPart', 'Cake\Network\Http\FormData\Part');
