<?php
// @deprecated Backwards compatibility with earlier 3.x versions.
class_alias('Cake\Http\Client\Adapter\Stream', 'Cake\Network\Http\Adapter\Stream');
