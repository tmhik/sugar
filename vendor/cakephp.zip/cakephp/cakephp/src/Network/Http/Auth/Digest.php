<?php
// @deprecated Backwards compatibility with earlier 3.x versions.
class_alias('Cake\Http\Client\Auth\Digest', 'Cake\Network\Http\Auth\Digest');
